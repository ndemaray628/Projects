### TEXT PREPROCESSING ########################################################

# Using the tm (text mining) library, this script takes the raw text from 10000
# yelp reviews and creates a new dataset containing the counts of the top 1000 
# most frequent words ranked by their total count across all documents.

rm(list = ls())
cat("\014")

setwd("E:/Final Project")

##### Setup #####

# Loading libraries
library(dplyr)
library(tm)
library(textstem)

# loading dataset
yelp <- read.csv("yelp.csv")

##### Text Pre-Processing #####
# Followed most of the steps from the following tutorial: 
# https://tilburgsciencehub.com/topics/manage-manipulate/manipulate-clean/textual/text-preprocessing/

# creating dataframe of only raw text
raw_text <- data.frame(doc_id = yelp$review_id, text = yelp$text)

# creating a corpus
corpus <- VCorpus(DataframeSource(raw_text)) %>%
  tm_map(content_transformer(tolower)) %>% # lowering case of all letters to reduce dimensionality
  tm_map(stripWhitespace) %>% # removing white space
  tm_map(removePunctuation) %>% # removing punctuation
  tm_map(removeWords, stopwords()) %>% # removing stopwords ("the", "an", etc.)
  tm_map(content_transformer(lemmatize_strings)) # lemmatizing words - stripping them down to their roots

# creating term document matrix: document vectors in matrix format,
# rows correspond to terms in document, columns represent documents in
# the corpus and cells correspond to count of a term in a particular document
term_doc_matrix <- TermDocumentMatrix(corpus, control = list(wordlengths = c(1,Inf)))
tdm <- as.matrix(term_doc_matrix)

# calculating frequencies of each word in the corpus
freqs <- rowSums(tdm) %>%
  sort(decreasing = T)

# defining dataframe of top 1000 words ranked by frequency
top_terms <- data.frame(term = names(freqs), freq = freqs)[1:1000,]

# transposing the dataframe so that terms are variables and documents are observations
top_1000 <- t(tdm[top_terms$term,])
top_1000 <- cbind(review_id = rownames(top_1000), top_1000)


# merging dataset with counts of 1000 most frequent terms, by review id
yelp_v2 <- merge(yelp, top_1000, by = "review_id", suffixes = c(""))

# converting count values to numeric variables
for(i in 14:ncol(yelp_v2)) {
  yelp_v2[, i] <- as.numeric(yelp_v2[[i]])
}

#### Saving New Datasets ####
write.csv(yelp_v2, "yelp1000.csv")
write.csv(top_terms, "top_terms.csv")
