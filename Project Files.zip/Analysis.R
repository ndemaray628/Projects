rm(list = ls())
cat("\014")

setwd("E:/Final Project")

##### Setup #####

# Loading libraries
library(ggplot2)
library(glmnet)
library(grf)
library(ROCR)
library(xtable)
library(stargazer)

# loading datasets
yelp <- read.csv("yelp1000.csv")
top_terms <- read.csv("top_terms.csv")

# defining a binary variable for review sentiment
sentiment <- ifelse(yelp$stars >= 3, 1, 0)

#### Training logit LASSO ####

# choosing indices to include in training sample
set.seed(0)
training_indices <- sample(1:nrow(yelp), size = (0.7 * nrow(yelp)))

# defining training and test sets based on training indices
train <- yelp[training_indices, ]
test <- yelp[-training_indices, ]

# creating matrix of words to be included as covariates in predictive model
x_train <- data.matrix(train[, -(1:11)])
x_test <- data.matrix(test[, -(1:11)])

# creating outcome variable for training and test sets

# binary outcome: review above or below 3 stars
y_train <- sentiment[training_indices]
y_test <- sentiment[-training_indices]

# logit LASSO with 3 fold cross validation
logit_lasso <- cv.glmnet(x = x_train, y = y_train, family = "binomial", alpha = 1, nfold = 3)

# calculating sentiment scores as predicted values of lasso model
sent_score <- predict(logit_lasso, s = "lambda.min", type = "response", newx = x_test)


###### Determining Optimal Cutoff #####
pred <- prediction(sent_score, y_test)
perf <- performance(pred, "tpr", "fpr")

# random classifier for sake of comparison
set.seed(1)
random <- runif(length(y_test))
pred_rand <- prediction(random, y_test)
perf_rand <- performance(pred_rand, "tpr", "fpr")

# Extracting cutoff values for classification
cutoffs <- unlist(pred@cutoffs)
tpr <- unlist(performance(pred, "tpr")@y.values)
fpr <- unlist(performance(pred, "fpr")@y.values)

# Computing true positive rate - false positive rate
youden_index <- tpr - fpr
best_cutoff <- cutoffs[which.max(youden_index)]

# classifying predictions using optimal cutoff
best_class <- ifelse(sent_score > best_cutoff, 1, 0)

# ROC curve(s)
sensitivity <- sum(best_class == 1 & y_test == 1) / sum(y_test == 1)
specificity <- sum(best_class == 0 & y_test == 0) / sum(y_test == 0)
false_pos <- 1 - specificity


plot(perf, main = "ROC Curve", xlab = "False Positive Rate", ylab = "True Positive Rate", col = "red", lwd = 2)
plot(perf_rand, add = TRUE, col = "green", lwd = 2)
abline(a = 0, b = 1, lty = 2, col = "gray")
points(false_pos, sensitivity, cex = 1, pch = 16)
legend("bottomright", 
       legend = c("Logit LASSO", "Random", sprintf("Cutoff: %.2f", best_cutoff)),
       col = c("red", "green", "black"),
       lwd = c(2, 2, NA),
       pch = c(NA,NA, 16))

# listing which covariates were selected for the model
coefs <- coef(logit_lasso, s = "lambda.min")[,1]
nonzeros <- coefs[which(coefs!= 0)][-1] |> sort(decreasing = T)

top_positives <- nonzeros[1:20]
top_negatives <- sort(nonzeros)[1:20]

word_df <- data.frame("Positive Words" = names(top_positives),
                      "Negative Words" = names(top_negatives))

# getting table to be printed
xtable_top_coeffs <- xtable(word_df)
print(xtable_top_coeffs, type = "latex", include.rownames = FALSE)

#### Model of review engagement ####

# defining a variable for total review engagement (sum of cool, funny, and useful reactions)
engagement <- yelp$cool + yelp$useful + yelp$funny

# keeping only observations with positive reviews
yelp_pos <- na.omit(yelp[which(sentiment == 1), ])
engagement_pos <- engagement[which(sentiment == 1)]

# choosing indices to include in training sample
set.seed(0)
en_indices <- sample(1:nrow(yelp_pos), size = (0.7 * nrow(yelp_pos)))

# defining training and test sets based on training indices
train_en <- yelp_pos[en_indices, ]
test_en <- yelp_pos[-en_indices, ]

# creating matrix of words to be included as covariates in predictive model
x_train_en <- data.matrix(train_en[, -(1:11)])
x_test_en <- data.matrix(test_en[, -(1:11)])

# outcome variable for train and test sets
y_train_en <- engagement_pos[en_indices]
y_test_en <- engagement_pos[-en_indices]

# training a simple lasso regression of engagement on word counts
set.seed(0)
lasso_engage <- cv.glmnet(x_train_en, y_train_en, alpha = 1, nfold = 3)

# finding which variables where selected by the lasso model
en_coef <- coef(lasso_engage, s = "lambda.min")[, 1]
en_nonzeros <- en_coef[which(en_coef != 0)][-1] |> sort(decreasing = T)

# getting fitted values -- in and out of sample
en_preds_IS <- predict(lasso_engage, newx = x_train_en, s = "lambda.min")
en_preds_OOS <- predict(lasso_engage, newx = x_test_en, s = "lambda.min")

# calculating out-of-sample R^2
R2IS <- 1 - sum((y_train_en - en_preds_IS)^2) / sum((y_train_en - mean(y_train_en))^2)
R2OOS <- 1 - sum((y_test_en - en_preds_OOS)^2) / sum((y_test_en - mean(y_test_en))^2)

# running post lasso to assess statistical significance of results using entire dataset
lasso_controls <- data.matrix(yelp_pos[, names(en_nonzeros)])
post_lasso_df <- cbind.data.frame(engagement = engagement_pos, lasso_controls)
post_lasso <- lm(engagement ~ ., data = post_lasso_df)

# outputting results as a table containing top coefficients in terms of magnitude
coef_summary <- summary(post_lasso)$coefficients
sorted_coefs <- coef_summary[order(abs(coef_summary[, "Estimate"]), decreasing = TRUE), ] |> round(digits = 4)
selected_coefs <- sorted_coefs[1:20,]
stargazer(selected_coefs, digits = 3, type = "latex", title = "Top 20 post-lasso estimates by magnitude")


#### Other Visuals ####

# Plotting word frequency for top 20 terms, ordering terms by their frequency
ggplot(top_terms[1:20,], aes(x = reorder(x = term, X = freq), y = freq, fill = freq)) +
  geom_col() +
  xlab("Terms") +
  ylab("Frequency") +
  ggtitle("Top 20 Words by Frequency") +
  scale_fill_gradient(name = "Frequency") +
  coord_flip() +
  theme_light()
ggsave("freq_rank.png")
