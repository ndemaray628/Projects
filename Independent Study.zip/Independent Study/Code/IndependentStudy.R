rm(list = ls())
cat("\014")
setwd("C:/Users/Nicolas/OneDrive/UCSC/Spring 2025/Independent Study/Data")

# INDEPENDENT STUDY ############################################################

# loading libraries
library(dplyr)
library(ggplot2)
library(stargazer)

## DATA CLEANING ###############################################################

# loading data
sat <- read.csv("SatellitePollution.csv") %>%
  rename(co_sat = CO_ppbv, no2_sat = NO2_molcm, date = Date)
ground <- read.csv("ispu_dki_all.csv") %>%
  rename(date = "tanggal")
traffic <- read.csv("combined_v0_live.csv")
names(traffic) <- sub("^X\\.", "", names(traffic))

# fixing the dates so they're all in the same format
traffic$dep_time_local <- as.POSIXct(traffic$dep_time_local, format = "%d %b %Y %H:%M:%S")
traffic$date <- format(traffic$dep_time_local, "%m-%d-%Y")
traffic$date <- as.Date(traffic$date, format = "%m-%d-%Y")

sat$date <- as.Date(sat$date, format = "%m/%d/%Y")
sat$date <- format(sat$date, "%m-%d-%Y")
sat$date <- as.Date(sat$date, format = "%m-%d-%Y")

ground$date <- format(as.Date(ground$date), "%m-%d-%Y")
ground$date <- as.Date(ground$date, format = "%m-%d-%Y")

# calculating average best guess duration by day to be used as the main measurement of traffic
duration <- aggregate(duration_in_traffic_bg ~ date, data = traffic, FUN = mean)

# merging the datasets together,  keeping only dates during time period of 
# interest: March 31 to May 9th
merge <- right_join(sat, ground, by = "date")[1:40, ]
merge$duration <- duration$duration_in_traffic_bg

# replacing fill values of -9999 with NA
merge[merge == -9999] <- NA

# Creating a binary variable for whether the data is collected in the period after
# the policy was disbanded
merge$post <- (merge$date >= "2016-04-05")

# Variables of interest:

# Date
# no2_sat: satellite measure of no2 column
# no2: ground measure of no2
# AOD: aerosol optical depth
# co_sat: satellite measure of CO
# co: ground measure of CO
# no2: ground measure of no2
# duration: expected travel time on former 3in1 roads and non 3in1 roads, 
# accounting for traffic

## Missing Data ################################################################

# creating binary variable for whether data is missing
merge$missing_aod <- is.na(merge$AOD)

# calculating how many days have missing AOD data
sum(merge$missing_aod)

# missing no2 data
sum(is.na(merge$no2_sat))

# missing co data
sum(is.na(merge$co_sat))

# instances where no2 is missing and either of the other two are missing
sum(is.na(merge$no2_sat) & (is.na(merge$AOD) | is.na(merge$co_sat)))

# identifying stretches of missing aod data
missing_aod_regions <- merge %>%
  mutate(group = cumsum(!missing_aod)) %>% # Track sequences
  filter(missing_aod) %>%
  group_by(group) %>%
  summarize(start = min(date), end = max(date), .groups = "drop")

# plot with shaded regions of missing data
ggplot(merge, aes(x = date, y = AOD)) +
  geom_point() +
  geom_line() +
  geom_rect(data = missing_aod_regions, inherit.aes = FALSE,
            aes(xmin = start, xmax = end, ymin = -Inf, ymax = Inf),
            fill = "red", alpha = 0.2) +
  labs(title = "Aerosol Optical Depth in Jakarta, Indonesia", subtitle = "March 31st, 2016 to May 9th, 2016",
       y = "AOD", x = "Date") +
  theme_light()

## Regressions to compare different outcome variables ##########################

# change in google maps API duration prediction accounting for traffic
duration_reg <- lm(log(duration) ~ post, data = merge)

# satellite CO vs ground CO:
sat_co_reg <- lm(log(co_sat) ~ post, data = merge)
ground_co_reg <- lm(log(co) ~ post, data = merge)
sat_no2_reg <- lm(log(no2_sat) ~ post, data = merge)
ground_no2_reg <- lm(log(no2) ~ post, data = merge)

stargazer(duration_reg, sat_co_reg, ground_co_reg, sat_no2_reg, ground_no2_reg, omit.stat = c("f", "ser"), type = "latex")
